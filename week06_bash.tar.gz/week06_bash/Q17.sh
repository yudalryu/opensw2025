#!/bin/bash

file_wordcnt() {
    for file in *.txt; do
        if [ -e "$file" ]; then
            result=$(wc -w < "$file")
            echo "$file 파일의 단어는 $result개 입니다."
        fi
    done
}

# 함수 한 번만 호출 (파라미터 전달 없음)
file_wordcnt
